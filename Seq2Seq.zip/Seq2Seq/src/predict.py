import torch
from model import TranslationModel
import config
from tokenizer import ChineseTokenizer,EnglishTokenizer

def predict_batch(model,inputs,en_tokenizer):
    model.eval()
    batch_size = inputs.shape[0]
    device = inputs.device
    with torch.no_grad():
        context_vector = model.encoder(inputs)
        decoder_hidden_0 = context_vector.unsqueeze(0)
        decoder_input = torch.full([batch_size,1],en_tokenizer.sos_token_index,device=device)
        # 自回归生成
        generated = []
        is_finished = torch.full([batch_size],fill_value=False,device=device)
        for i in range(config.MAX_SEQ_LEN):
            # 解码 更新隐藏状态
            decoder_output,decoder_hidden_n = model.decoder(decoder_input,decoder_hidden_0)
            decoder_hidden_0 = decoder_hidden_n
            next_token_indexes = torch.argmax(decoder_output,dim=-1)
            generated.append(next_token_indexes)
            
            # 更新输入
            decoder_input = next_token_indexes
            
            # 判断是否应该结束
            is_finished = is_finished | next_token_indexes.squeeze(1) == en_tokenizer.eos_token_index
            if is_finished.all():
                break
        generated_tensor = torch.cat(generated,dim=1).tolist()
        
        for index,sentence in enumerate(generated_tensor):
            if en_tokenizer.eos_token_index in sentence:
                eos_pos = sentence.index(en_tokenizer.eos_token_index)
                generated_tensor[index]=sentence[:eos_pos]
            
    return generated_tensor

def predict(text,model,zh_tokenizer,en_tokenizer,device):

    # 4.处理输入
    indexes = zh_tokenizer.encode(text)

    input_tensor = torch.tensor([indexes],dtype=torch.long).to(device)

    # 5.预测逻辑
    batch_result = predict_batch(model,input_tensor,en_tokenizer)
    return en_tokenizer.decode(batch_result[0])

def run_predict():
    # 1.确定训练设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # 2.词表
    zh_tokenizer = ChineseTokenizer.from_vocab(config.model_path/'zh_vocab.txt')
    en_tokenizer = EnglishTokenizer.from_vocab(config.model_path/'en_vocab.txt')
    

    # 3.模型
    model = TranslationModel(zh_tokenizer.vacab_size,en_tokenizer.vacab_size,zh_tokenizer.pad_token_index,en_tokenizer.pad_token_index).to(device)
    model.load_state_dict(torch.load(config.model_path / 'best.pt'))

    print("欢迎机器翻译模型,输入q或者quit退出")
    while True:
        user_input = input("中文：")
        if user_input.strip() != '':
            if  user_input in ['q','quit']:
                break
            result = predict(user_input,model,zh_tokenizer,en_tokenizer,device)
            print(f"英文:{result}")

        else:
            print(">")
            continue

if __name__ == "__main__":
    run_predict()
    