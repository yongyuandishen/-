from torch import nn
import config
import torch
import math

class PositionEncoding(nn.Module):
    def __init__(self,max_len,d_model):
        super().__init__()
        pe = torch.zeros([max_len,d_model])
        for pos in range(max_len):
            for _2i in range(0,d_model,2):
                pe[pos,_2i] = math.sin(pos/(10000 **(_2i / d_model)))
                pe[pos,_2i+1] =math.cos(pos/(10000 **(_2i / d_model)))
        self.register_buffer("pe",pe)

    def forward(self,x):
        # x.shape:[batch,seq_len,dim_model]
        seq_len = x.shape[1]
        part_pe=self.pe[:seq_len]
        return x + part_pe

class TranslationModel(nn.Module):
    def __init__(self,zh_vocab_size,en_vocab_size,zh_padding_index,en_padding_index):
        super().__init__()
        self.zh_embedding = nn.Embedding(num_embeddings=zh_vocab_size,embedding_dim=config.dmodel,padding_idx=zh_padding_index)
        self.en_embedding = nn.Embedding(num_embeddings=en_vocab_size,embedding_dim=config.dmodel,padding_idx=en_padding_index)
        # 位置编码
        self.postion_encoding = PositionEncoding(config.SEQ_LEN,config.dmodel)
        # 模型
        self.transformer = nn.Transformer(d_model=config.dmodel,
         nhead=config.nhead,num_encoder_layers=config.num_layer,
                                          num_decoder_layers=config.num_layer,
                                          batch_first=True)
        
        self.linear = nn.Linear(in_features=config.dmodel,out_features=en_vocab_size)

    def forward(self,src,src_pad_mask,tgt,tgt_mask):
        memory = self.encode(src,src_pad_mask)
        return self.decode(tgt,memory,tgt_mask,src_pad_mask)


    def encode(self,src,src_pad_mask):
        # src.shape = [batch_size,src_len]
        # src.src_pad_mask.shape = [batch_size,src_len]
        embed = self.zh_embedding(src)
        # embed.shape = [batch_size,src_len,dmodel]
        embed = self.postion_encoding(embed)
        memory = self.transformer.encoder(src=embed,src_key_padding_mask=src_pad_mask)
        # memory.shape = [batch_size,src_len,dmodel]
        return memory
    
    def decode(self,tgt,memory,tgt_mask,memory_key_padding_mask):
        # tgt.shape = [batch_size,tgt_len]
        embed = self.en_embedding(tgt)
        embed = self.postion_encoding(embed)
        # embed.shape = [batch_size,tgt_len,dmodel]
        output = self.transformer.decoder(tgt=embed,memory=memory,tgt_mask=tgt_mask,memory_key_padding_mask=memory_key_padding_mask)
        outputs = self.linear(output)
        # output.shape = [batch_size,tgt_len,en_vocab_size]
        return outputs