from pathlib import Path
SEQ_LEN=50
root_dir = Path(__file__)
data_path=root_dir.parent.parent/"data" / "raw"
process_path=root_dir.parent.parent/"data" / "processed"
log_path = root_dir.parent.parent/"logs"
model_path = root_dir.parent.parent /"models"
BATCH_SIZE=64
dmodel = 128
nhead =4
num_layer =2
HIDDEN_SIZE = 256
lr = 1e-3
EPOCHS = 10
MAX_SEQ_LEN = 128