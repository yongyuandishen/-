from torch.utils.tensorboard import SummaryWriter
import torch
from dataset import get_dataloader
from tokenizer import ChineseTokenizer,EnglishTokenizer
import config
from model import TranslationModel
import time
from tqdm import tqdm

def train_one_epoch(model,dataloader,loss_fn,optimizer,device):
    model.train()
    total_loss = 0
    for inputs,targets in tqdm(dataloader,desc="训练"):
        encoder_inputs = inputs.to(device) 
        targets = targets.to(device)
        decoder_inputs = targets[:,:-1]
        decoder_targets = targets[:,1:]
        #decoder_targets:[batch_size,seq_len]
        # context_vector:[batch_size,hidden_size]
        src_pad_mask = (encoder_inputs == model.zh_embedding.padding_idx)
        tgt_mask = model.transformer.generate_square_subsequent_mask(decoder_inputs.shape[1])    
        decoder_outputs = model(encoder_inputs, src_pad_mask, decoder_inputs, tgt_mask)
        loss = loss_fn(decoder_outputs.reshape(-1,decoder_outputs.shape[-1]),decoder_targets.reshape(-1))
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()
        
    return total_loss / len(dataloader)



def train():
    # 设备
    device =torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    # 数据
    dataloader = get_dataloader()
    # 分词器
   
    zh_tokenizer = ChineseTokenizer.from_vocab(config.model_path/'zh_vocab.txt')
    en_tokenizer = EnglishTokenizer.from_vocab(config.model_path/'en_vocab.txt')
    print(f"分词器中的英文词表大小: {en_tokenizer.vacab_size}")
    # 模型
    model = TranslationModel(zh_tokenizer.vacab_size,en_tokenizer.vacab_size,
                             zh_tokenizer.pad_token_index,en_tokenizer.pad_token_index).to(device)
    # 损失函数
    loss_fn = torch.nn.CrossEntropyLoss(ignore_index=en_tokenizer.pad_token_index)

    # 优化器
    optimizer = torch.optim.Adam(model.parameters(),lr = config.lr)
    # tensor_board writer
    writer =  SummaryWriter(log_dir = config.log_path / time.strftime('%Y-%m-%d-%H-%M'))

    best_loss = float('inf')
    for epoch in range(1,config.EPOCHS+1):
        print(f"==========Epoch{epoch}=========")
        loss = train_one_epoch(model,dataloader,loss_fn,optimizer,device)

        print(f'Loss:{loss:4f}')
        # 记录tensor_board
        writer.add_scalar(tag='Loss', scalar_value=loss, global_step=epoch)
        
        # 保存模型
        if loss< best_loss:
            best_loss = loss
            torch.save(model.state_dict(),config.model_path / 'best.pt')
            print('保存模型')

        writer.close()

if __name__ == "__main__":
    train()