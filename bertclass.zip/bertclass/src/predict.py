import torch
from transformers import AutoTokenizer,AutoModelForSequenceClassification
import torch
import config
import jieba


def predict_batch(model,inputs):
    model.eval()
    with torch.no_grad():
        output = model(**inputs)
        logits = output.logits
    logits = torch.argmax(logits,dim=1)
    return logits.tolist()

def predict(text,model,tokenzier,device):

    # 4.处理输入
    inputs= tokenzier(text,padding="max_length",max_length=config.SEQ_LEN,truncation=True,return_tensors='pt')

    # 5.预测逻辑
    inputs = {k:v.to(device) for k,v in inputs.items()}
    batch_result = predict_batch(model,inputs)
    return batch_result[0]

def run_predict():
    # 1.确定训练设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # 2.词表
    tokenizer = AutoTokenizer.from_pretrained('bert-base-chinese')

    # 3.模型
    model = AutoModelForSequenceClassification.from_pretrained(config.model_path).to(device)

    print("欢迎使用情感分析模型,输入q或者quit退出")
    while True:
        user_input = input(">")
        if user_input.strip() != '':
            if  user_input in ['q','quit']:
                break
            result = predict(user_input,model,tokenizer,device)
            
            if result == 1:
                print("预测结果：正向")
            else:
                print("预测结果：负向")

        else:
            print(">")
            continue

if __name__ == "__main__":
    run_predict()
    