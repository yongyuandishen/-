import torch
import config
from dataset import get_dataloader
from transformers import AutoModel,AutoModelForSequenceClassification
from predict import predict_batch

def evaluate(model,test_dataloader,device):
    total_count = 0
    corr_accout = 0
    for batch in test_dataloader:
        inputs = {k:v.to(device) for k ,v in batch.items()}
        labels = inputs.pop('labels').tolist()
        batch_result = predict_batch(model,inputs)
        for result,labels in zip(batch_result,labels):
            result = 1 if result>0.5 else 0
            if result == labels:
                corr_accout += 1
            total_count +=1
    return corr_accout/total_count

def run_evaluate():

     # 1.确定训练设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # 3.模型
    model = AutoModelForSequenceClassification.from_pretrained(config.model_path).to(device)
    print("模型加载成功")

    # 4.数据集
    test_dataloader = get_dataloader(train=False)
    # 评估逻辑
    print("开始评估")
    acc = evaluate(model,test_dataloader,device)
    print(acc)

if __name__ == "__main__":
    run_evaluate()