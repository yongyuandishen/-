import torch
import config
from model import TranslationModel
from dataset import get_dataloader
from tokenizer import ChineseTokenizer,EnglishTokenizer
from predict import predict_batch
from nltk.translate.bleu_score import corpus_bleu

def evaluate(model,test_dataloader,device,en_tokenizer):
    predictions = []
    references = []
    for inputs,targets in test_dataloader:
        inputs = inputs.to(device)
        targets = targets.tolist()
        batch_result = predict_batch(model,inputs,en_tokenizer)
        predictions.extend(batch_result)
        references.extend([target[1:target.index(en_tokenizer.eos_token_index)]] for target in targets)
    return corpus_bleu(references,predictions)
def run_evaluate():

     # 1.确定训练设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # 2.词表
    zh_tokenizer = ChineseTokenizer.from_vocab(config.model_path / 'zh_vocab.txt')
    en_tokenizer = EnglishTokenizer.from_vocab(config.model_path / 'en_vocab.txt')

    # 3.模型
    model = TranslationModel(zh_tokenizer.vacab_size,en_tokenizer.vacab_size,zh_tokenizer.pad_token_index,en_tokenizer.pad_token_index).to(device)
    model.load_state_dict(torch.load(config.model_path / 'best.pt'))
    print("模型加载成功")

    # 4.数据集
    test_dataloader = get_dataloader(train=False)
    # 评估逻辑
    print("开始评估")
    bleu = evaluate(model,test_dataloader,device,en_tokenizer)
    print(bleu)

if __name__ == "__main__":
    run_evaluate()