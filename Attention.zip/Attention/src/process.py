import pandas as pd
from sklearn.model_selection import train_test_split
import torch
import config
from tokenizer import ChineseTokenizer,EnglishTokenizer

def process():
    df = pd.read_csv(filepath_or_buffer=config.data_path / 'cmn.txt',sep='\t',header=None,usecols=[0,1],
                names=['en','zh'],encoding='utf-8').dropna()
    # 划分数据集
    train_df,test_df = train_test_split(df,test_size=0.2)
    # 构建词表
    ChineseTokenizer.build_vocab(train_df['zh'].tolist(),config.model_path / 'zh_vocab.txt')
    EnglishTokenizer.build_vocab(train_df['en'].tolist(),config.model_path / 'en_vocab.txt')
    # 构建训练集
    zh_tokenizer = ChineseTokenizer.from_vocab(config.model_path/'zh_vocab.txt')
    en_tokenizer = EnglishTokenizer.from_vocab(config.model_path/'en_vocab.txt')
    train_df['zh'] = train_df['zh'].apply(lambda x:zh_tokenizer.encode(x,add_sos_eos=False))
    train_df['en'] =train_df['en'].apply(lambda x:en_tokenizer.encode(x,add_sos_eos=True))
    train_df.to_json(config.process_path / 'train.jsonl',orient='records',lines=True)
    # 构建测试集
    test_df['zh'] = test_df['zh'].apply(lambda x:zh_tokenizer.encode(x,add_sos_eos=False))
    test_df['en'] =test_df['en'].apply(lambda x:en_tokenizer.encode(x,add_sos_eos=True))
    test_df.to_json(config.process_path / 'test.jsonl',orient='records',lines=True)
if __name__ == "__main__":
    process()