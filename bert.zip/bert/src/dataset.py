# 1.定义Dataset
from torch.utils.data import Dataset,DataLoader
from datasets import load_from_disk
import pandas as pd
import torch
import config
    
def get_dataloader(train=True):
    path = str(config.process_path / ('train' if train else 'test'))
    dataset = load_from_disk(path)
    dataset.set_format(type='torch')
    return DataLoader(dataset,batch_size=config.BATCH_SIZE,shuffle=True)

if __name__ == '__main__':
    train_dataloader = get_dataloader()
    test_dataloader = get_dataloader(train=False)
    for batch in train_dataloader:
        for k,v in batch.items():
            print(k,v.shape)

        break
    