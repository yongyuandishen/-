
import config
from transformers import AutoModel,AutoTokenizer,AutoModelForSequenceClassification
import torch
from datasets import load_dataset
from torch.utils.data import DataLoader
from datasets import ClassLabel

def process():
    print('开始处理数据')
    file_path = str(config.data_path/ "online_shopping_10_cats.csv")
    dataset = load_dataset("csv",data_files=file_path,split="train")
    dataset = dataset.remove_columns(['cat'])
    dataset = dataset.filter(lambda x:x['review'] is not None)
    dataset = dataset.cast_column("label",ClassLabel(names=['negative','positive']))
    dataset_dict = dataset.train_test_split(test_size=0.2,stratify_by_column = 'label')
    # # 划分数据集
    # train_df,test_df = train_test_split(df,test_size =0.2,stratify=df['label'])
    # # 构建词表
    # JiebaTokenizer.build_vocab(train_df['review'].tolist(),config.model_path / 'vocab.txt')
    # # 构建训练集
    tokenizer = AutoTokenizer.from_pretrained("bert-base-chinese")

    def batch_encode(batch):
        inputs = tokenizer(batch['review'],padding='max_length',truncation=True,max_length=config.SEQ_LEN)
        inputs['labels']= batch['label']
        return inputs
    dataset_dict = dataset_dict.map(batch_encode,batched=True,remove_columns=['review','label'])
    dataset_dict.save_to_disk(config.process_path)
if __name__ == "__main__":
    process()