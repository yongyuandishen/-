from torch import nn
import config
import torch
from transformers import AutoModel,AutoTokenizer,AutoModelForSequenceClassification
class ReviewAnalyzeModel(nn.Module):
    def __init__(self):
        super().__init__()
        
        self.bert = AutoModel.from_pretrained('bert-base-chinese')
        self.linear = nn.Linear(self.bert.config.hidden_size,out_features=1)

    def forward(self,input_ids,attention_mask,token_type_ids):
        # x.shape:[batch_size,seq_len]
        output = self.bert(input_ids,attention_mask,token_type_ids)
        cls_hidden = output.last_hidden_state[:,0,:]

        output = self.linear(cls_hidden).squeeze(-1)
        return output