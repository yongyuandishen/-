from pathlib import Path
SEQ_LEN=128
root_dir = Path(__file__)
data_path=root_dir.parent.parent/"data" / "raw"
process_path=root_dir.parent.parent/"data" / "processed"
log_path = root_dir.parent.parent/"logs"
model_path = root_dir.parent.parent /"models"
pre_trained_path = root_dir / "pre_trained"
BATCH_SIZE=8
EMBEDDING_DIM=128
HIDDEN_SIZE = 256
lr = 1e-5
EPOCHS = 3
