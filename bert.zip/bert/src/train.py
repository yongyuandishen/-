from torch.utils.tensorboard import SummaryWriter
from transformers import AutoModel,AutoTokenizer,AutoModelForSequenceClassification
import torch
from dataset import get_dataloader
import config
from model import ReviewAnalyzeModel
import time
from tqdm import tqdm

def train_one_epoch(model,dataloader,loss_fn,optimizer,device):
    model.train()
    total_loss = 0
    for batch in tqdm(dataloader,desc="训练"):
        inputs = {k:v.to(device) for k ,v in batch.items()}
        labels = inputs.pop('labels').to(dtype=torch.float)
        outputs = model(**inputs)
        loss = loss_fn(outputs,labels)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
    return total_loss / len(dataloader)



def train():
    # 设备
    device =torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    # 数据
    dataloader = get_dataloader()
    # 分词器
    tokennizer = AutoTokenizer.from_pretrained('bert-base-chinese')
    # 模型
    model = ReviewAnalyzeModel().to(device)
    # 损失函数
    loss_fn = torch.nn.BCEWithLogitsLoss()
    # 优化器
    optimizer = torch.optim.Adam(model.parameters(),lr = config.lr)
    # tensor_board writer
    writer =  SummaryWriter(log_dir = config.log_path / time.strftime('%Y-%m-%d-%H-%M'))

    best_loss = float('inf')
    for epoch in range(1,config.EPOCHS+1):
        print(f"==========Epoch{epoch}=========")
        loss = train_one_epoch(model,dataloader,loss_fn,optimizer,device)

        print(f'Loss:{loss:4f}')
        # 记录tensor_board
        writer.add_scalar(tag='Loss', scalar_value=loss, global_step=epoch)
        
        # 保存模型
        if loss< best_loss:
            best_loss = loss
            torch.save(model.state_dict(),config.model_path / 'best.pt')
            print('保存模型')

        writer.close()

if __name__ == "__main__":
    train()