import torch
from model import ReviewAnalyzeModel
import config
import jieba
from tokenizer import JiebaTokenizer

def predict_batch(model,inputs):
    model.eval()
    with torch.no_grad():
        output = model(inputs)
        batch_result = torch.sigmoid(output)
    return batch_result.tolist()

def predict(text,model,tokenzier,device):

    # 4.处理输入
    indexes = tokenzier.encode(text,config.SEQ_LEN)

    input_tensor = torch.tensor([indexes],dtype=torch.long).to(device)

    # 5.预测逻辑
    batch_result = predict_batch(model,input_tensor)
    return batch_result[0]

def run_predict():
    # 1.确定训练设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # 2.词表
    tokenizer = JiebaTokenizer.from_vocab(config.model_path/'vocab.txt')

    # 3.模型
    model = ReviewAnalyzeModel(tokenizer.vacab_size,tokenizer.pad_token_index).to(device)
    model.load_state_dict(torch.load(config.model_path / 'best.pt'))

    print("欢迎使用情感分析模型,输入q或者quit退出")
    while True:
        user_input = input(">")
        if user_input.strip() != '':
            if  user_input in ['q','quit']:
                break
            result = predict(user_input,model,tokenizer,device)
            
            if result>0.5:
                print(f"预测结果：正向(置信度:{result})")
            elif result==0.5:
                print(f"预测结果：中性")
            else:
                print(f"预测结果：负向(置信度:{result})")

        else:
            print(">")
            continue

if __name__ == "__main__":
    run_predict()
    