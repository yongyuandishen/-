# 1.定义Dataset
from torch.utils.data import Dataset,DataLoader
import pandas as pd
import torch
import config


class ReviewAnalyzeDataset(Dataset):
    def __init__(self,path):
        self.data = pd.read_json(path,lines=True,orient="records").to_dict(orient="records")
    def __len__(self):
        return len(self.data)
    def __getitem__(self, index):
        input_tensor= torch.tensor(self.data[index]["review"],dtype=torch.long)
        target_tensor= torch.tensor(self.data[index]["label"],dtype=torch.float)
        return input_tensor,target_tensor
    
def get_dataloader(train=True):
    path = config.process_path / ('train.jsonl' if train else 'test.jsonl')
    dataset = ReviewAnalyzeDataset(path)
    return DataLoader(dataset,batch_size=config.BATCH_SIZE,shuffle=True)

if __name__ == '__main__':
    train_dataloader = get_dataloader()
    test_dataloader = get_dataloader(train=False)
    for input_tensor,target_tensor in train_dataloader:
        print(input_tensor.shape)
        print(target_tensor.shape)
        break
    