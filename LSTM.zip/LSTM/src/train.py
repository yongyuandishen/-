from torch.utils.tensorboard import SummaryWriter
import torch
from dataset import get_dataloader
from tokenizer import JiebaTokenizer
import config
from model import ReviewAnalyzeModel
import time
from tqdm import tqdm

def train_one_epoch(model,dataloader,loss_fn,optimizer,device):
    model.train()
    total_loss = 0
    for inputs,targets in tqdm(dataloader,desc="训练"):
        inputs = inputs.to(device)
        targets = targets.to(device)
        outputs = model(inputs)
        loss = loss_fn(outputs,targets)
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()
        total_loss += loss.item()
    return total_loss / len(dataloader)



def train():
    # 设备
    device =torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    # 数据
    dataloader = get_dataloader()
    # 分词器
    tokennizer = JiebaTokenizer.from_vocab(config.model_path/'vocab.txt')
    # 模型
    model = ReviewAnalyzeModel(tokennizer.vacab_size,tokennizer.pad_token_index).to(device)
    # 损失函数
    loss_fn = torch.nn.BCEWithLogitsLoss()
    # 优化器
    optimizer = torch.optim.Adam(model.parameters(),lr = config.lr)
    # tensor_board writer
    writer =  SummaryWriter(log_dir = config.log_path / time.strftime('%Y-%m-%d-%H-%M'))

    best_loss = float('inf')
    for epoch in range(1,config.EPOCHS+1):
        print(f"==========Epoch{epoch}=========")
        loss = train_one_epoch(model,dataloader,loss_fn,optimizer,device)

        print(f'Loss:{loss:4f}')
        # 记录tensor_board
        writer.add_scalar(tag='Loss', scalar_value=loss, global_step=epoch)
        
        # 保存模型
        if loss< best_loss:
            best_loss = loss
            torch.save(model.state_dict(),config.model_path / 'best.pt')
            print('保存模型')

        writer.close()

if __name__ == "__main__":
    train()