from torch import nn
import config
import torch
class ReviewAnalyzeModel(nn.Module):
    def __init__(self,vocab_size,padding_index):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size,config.EMBEDDING_DIM,padding_idx=padding_index)
        self.gru = nn.GRU(input_size=config.EMBEDDING_DIM,hidden_size=config.HIDDEN_SIZE,batch_first=True)
        self.linear = nn.Linear(config.HIDDEN_SIZE,out_features=1)

    def forward(self,x):
        # x.shape:[batch_size,seq_len]
        embed =self.embedding(x)
        # embed.shape:[batch_size,seq_len,embedding-dim]
        output,_= self.gru(embed)
        # output.shape:[batch_size,seq_len,hidden_size]
        batch_indexes = torch.arange(0,output.shape[0])
        lengths = (x !=self.embedding.padding_idx).sum(dim=1)
        last_hidden = output[batch_indexes,lengths-1]
        # last_hidden.shape:[bactch_size,hidden_size]

        output = self.linear(last_hidden).squeeze(-1)
        return output